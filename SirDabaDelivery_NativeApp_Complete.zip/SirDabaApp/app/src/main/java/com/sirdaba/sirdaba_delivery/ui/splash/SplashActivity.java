package com.sirdaba.sirdaba_delivery.ui.splash;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.sirdaba.sirdaba_delivery.R;
import com.sirdaba.sirdaba_delivery.ui.dashboard.DashboardActivity;
import com.sirdaba.sirdaba_delivery.ui.login.LoginActivity;
import com.sirdaba.sirdaba_delivery.utils.TokenManager;

public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_DELAY = 2000; // 2 ثانية

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            // التحقق من حالة تسجيل الدخول
            if (TokenManager.isLoggedIn(this)) {
                startActivity(new Intent(this, DashboardActivity.class));
            } else {
                startActivity(new Intent(this, LoginActivity.class));
            }
            finish();
        }, SPLASH_DELAY);
    }
}
